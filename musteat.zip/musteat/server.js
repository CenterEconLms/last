const express = require('express');
const app = express();
var dbConfig = require(__dirname + '/db.js');
var conn = dbConfig.init();
const bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({ extended: false }));
dbConfig.connect(conn);

app.listen(8080,function(){
    console.log("listening 8080")

});
app.get('/',function(요청,응답){
    응답.sendFile(__dirname + '/index.html')
});


/*
app.get('/db_add', function(req, res) {
  res.render('add');
});
app.post('/db_add', function(req, res) {
  var name = req.body.name;
  var adress = req.body.adress;
  var star = req.body.star;

  var sql= 'INSERT INTO topic (name, adress, star) VALUES (?, ?, ?)';
  conn.query(sql, [name, adress, star], function(err, result, field){
    if(err){
      console.log(err);
      res.status(500).send('Internal Server  Error');
    }
  });
});*/