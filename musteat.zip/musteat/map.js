var mapDiv = document.getElementById('map');
var map = new naver.maps.Map(mapDiv);
